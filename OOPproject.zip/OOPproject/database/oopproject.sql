-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2017 at 08:12 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oopproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `roomid` varchar(10000) NOT NULL,
  `rent` varchar(1000) NOT NULL,
  `status` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL,
  `Firstname` varchar(100) NOT NULL,
  `lastname` varchar(1000) NOT NULL,
  `Roomnumber` varchar(1000) NOT NULL,
  `roompreference` varchar(10000) NOT NULL,
  `Purpose` varchar(10000) NOT NULL,
  `numberofattendence` varchar(10000) NOT NULL,
  `checkindate` varchar(100) NOT NULL,
  `checkoutdate` varchar(100) NOT NULL,
  `Description` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id`, `Firstname`, `lastname`, `Roomnumber`, `roompreference`, `Purpose`, `numberofattendence`, `checkindate`, `checkoutdate`, `Description`) VALUES
(12, 'nahed', 'hasan', 'F1-103', 'projector', 'seminer', '10+', '12/07/2017', '12/08/2017', 'wwwwwwwwwwwwwwwwwww'),
(13, 'Nahed ', 'Hasan', 'F1-103', 'a/c', 'seminer', '2', '12/15/2017', '12/21/2017', 'ufshg8wuorehgwiurehjgbyvhjergbuerhjghduerhj');

-- --------------------------------------------------------

--
-- Table structure for table `roominfo`
--

CREATE TABLE `roominfo` (
  `id` int(11) NOT NULL,
  `roomtitle` varchar(10000) NOT NULL,
  `roomno` varchar(100) NOT NULL,
  `location` varchar(1000) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `schedule` varchar(1000) NOT NULL,
  `pics` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roominfo`
--

INSERT INTO `roominfo` (`id`, `roomtitle`, `roomno`, `location`, `description`, `schedule`, `pics`) VALUES
(12, 'Meeting room', 'F1-001 ', '1st floor', 'Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to b', '10.00am-4.00pm ', 'images/5.jpg'),
(13, 'conference Room', 'F1-002', '1st floor,infront of the building.', 'Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to b', '10.00am-4.00pm ', 'images/1.jpg'),
(14, 'seminer Room', 'F1-003', '2nd floor of the building. ', 'Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to b', '10.00am-4.00pm ', 'images/3.jpg'),
(15, 'workshop Room', ' F1-004 ', '2nd floor north part of the building. ', 'Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed. Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to be developed.Room Application Management system is a web based system for managing shared office, meeting, laboratory, and teaching space is to b', '10.00am-4.00pm ', 'images/2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`) VALUES
(13, 'noman', 'noman', 'noman'),
(14, 'sazzad', 'sazzad', 'sazzad'),
(15, 'Nahed', 'asa', 'asa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roominfo`
--
ALTER TABLE `roominfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `roominfo`
--
ALTER TABLE `roominfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
