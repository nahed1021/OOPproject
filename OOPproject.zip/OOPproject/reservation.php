<?php 
    require 'main/database.php';

                
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>room booking system</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Majestic hotel booking form Widget a Flat Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<!-- Meta tag Keywords -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" /><!-- Style-CSS -->
<link rel="stylesheet" href="css/font-awesome.min.css"><!--fontawesome-css--> 
<script src="js/jquery-2.1.4.min.js"></script>
<link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
</head>
<body>


<section class="booking-agile">

				           <div class="agileinf-button">    
				           <a class="read" href="main/index.php" target="--blank">
											Back to homepage
							   </a>
							   </div>
									

									

<h1>Room reservation</h1>
<div class="headbooking-agile">
			<div class="bookingleft-agile">
				<h2>make a reservation</h2>
					<form method="post">
						<div class="arrival-agile">
							<p>check-in date</p>
							<input placeholder="Check in" name="checkindate" class="date" id="datepicker" type="text" value=""  required=""/>
						</div>
						<div class="departure-agile">
							<p>check-out date</p>
							<input placeholder="Check out" name="checkoutdate" class="date" id="datepicker1" type="text" value="" required="" />
						</div>
						<div class="clear"></div>
							<div class="guest-agile">
								<p>number of attendence</p>
									<select name="numberofattendence">
										<option value="">number of attendence</option>
										<option value="2">2</option>
										<option value="5+">5+</option>
										<option value="10+">10+</option>
										<option value="15+">15+</option>
										
									</select>
							</div>
							<div class="room-agile">
								<p>Purpose</p>
									<select name="Purpose">
									  <option value="">room for</option>
									  <option value="meeting">meeting</option>
									  <option value="conference">conference</option>
									  <option value="seminer">seminer</option>
									  <option value="workshop">workshop</option>
									</select>
							</div>
							<div class="clear"></div>
							<div class="room-agile">
									<p>room preference</p>
								<select name="roompreference">
								  <option value="">select preference</option>
								  <option value="LED">LED</option>
								  <option value="wi-fi">wi-fi</option>
								  <option value="a/c">a/c</option>
								  <option value="projector">projector</option>
								  <option value="computer">computer</option>

								</select>
							</div>
							<div class="room-agile">
								<p>Room number</p>
							<select name="Roomnumber">
							  <option value=""></option>
							  <option value="F1-101">F1-101</option>
							  <option value="F1-102">F1-102</option>
							  <option value="F1-103">F1-103</option>
							  <option value="F1-104">F1-104</option>
							  <option value="F1-105">F1-105</option>
							</select>
							</div>
							<div class="clear"></div>
							<div class="name-agile">
								<p>First name</p>
								<input type="text" name="Firstname" placeholder="first name">
							</div>
							<div class="last-agile">
								<p>last name	</p>
								<input type="text" name="lastname" placeholder="last name" >
							</div>
							<div class="last-agile">
								<p>Description</p>
								<textarea name="Description" rows="3" cols="60" required=""></textarea>
							</div>
							<div class="clear"></div>
								<div class="submit-agile">
									<input type="submit" name="reserveclick" value="confirme reservation">
								</div>
								<div class="clear"></div>
								
						</form>
				</div>

<?php

            if ($_SERVER['REQUEST_METHOD'] == 'POST')
            {
                $checkindate=$_POST['checkindate'];
                $checkoutdate = $_POST['checkoutdate'];
                $numberofattendence = $_POST["numberofattendence"];
                $Purpose=$_POST['Purpose'];
                $roompreference = $_POST['roompreference'];
                $Roomnumber = $_POST["Roomnumber"];
                 $Firstname=$_POST['Firstname'];
                $lastname = $_POST['lastname'];
                $Description = $_POST["Description"];
                
                $st="Insert into reservation(checkindate,checkoutdate,numberofattendence,Purpose,roompreference,Roomnumber,Firstname,lastname,Description)
                 values('$checkindate','$checkoutdate','$numberofattendence','$Purpose','$roompreference','$Roomnumber','$Firstname','$lastname','$Description');";
                
                Insert($st);
                echo "<script> location.href='main/reservationhistory.php';</script>";
            }


?>






<div class="bookingright-agile">
<h3>get in touch</h3>
			<div class="mobile-agile">
				<div class="icon-agile">
					<span><i class="fa fa-phone" aria-hidden="true"></i></span>
				</div>
				<div class="contact-agile">
					<p>phone</p>
					<span>+8801704557252</span>
				</div>

			</div>
			<div class="mobile-agile">
				<div class="icon-agile">
					<span><i class="fa fa-facebook" aria-hidden="true"></i></span>
				</div>
				<div class="contact-agile">
					<p>facebook</p>
					<span><a href="https://www.facebook.com/nahed.hasan.906" target="__blank" >Nahed hasan</a></span>
				</div>
			</div>

			<div class="mobile-agile">
				<div class="icon-agile">
					<span><i class="fa fa-twitter" aria-hidden="true"></i></span>
				</div>
				<div class="contact-agile">
					<p>twitter</p>
					<span><a href="https://twitter.com/nahedhasan1021"target="__blank" >Nahed hasan</a></span>
				</div>
			</div>

			<div class="mobile-agile">
				<div class="icon-agile">
					<span><i class="fa fa-instagram" aria-hidden="true"></i></span>
				</div>
				<div class="contact-agile">
					<p>instagram</p>
					<span><a href="https://www.instagram.com/nahedhasan351021/" target="__blank" >Nahed hasan</a></span>
				</div>
			</div>

			<div class="clear"></div>
			<div class="email-agile">
				<div class="mail-agile">
					<span><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
				</div>
				<div class="address-agile">
					<p>email</p>
					<span><a href="https://www.gmail.com" target="__blank" >nahed35-1021@diu.edu.bd</a></span>
				</div>


				
				<div class="clear"></div>
				<div class="offers-agile">
					<h4>partner</h4>
				<ul class="offers">
					<li><a href="https://daffodilvarsity.edu.bd/" target="__blank" >Daffodil international university</a></li>
					
				</ul>
					
				</div> 
			</div>
</div>
<div class="clear"></div>
</div>
<footer></footer>
</section>
<!--start-date-piker-->
		<link rel="stylesheet" href="css/jquery-ui.css" />
		<script src="js/jquery-ui.js"></script>
			<script>
				$(function() {
				$( "#datepicker,#datepicker1" ).datepicker();
				});
			</script>
<!-- /End-date-piker -->
</body>
</html>