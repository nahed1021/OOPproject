Hi..
                                                        
The project is a Online room reservation System ,,,, Where  you can Reaserve a room for any purpose.
To using this system You have to install the XAMPP.exe file.Then Import oopproject.sql file from database folder.


To reserve a room follow Follow the Sequence 
 -> Click on the Room picture for the room details
 ->after view room details user have to log in the system to reserve room
 ->if the user new in the system then have to register 
 -> Login in the System as user
 -> Then Give the Required reservation Information 
 -> Then you can reserve the Room 
 -> after reservation u can see the reservation details