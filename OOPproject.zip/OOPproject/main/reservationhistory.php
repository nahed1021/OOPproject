<?php 
    require 'database.php';

                
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>room booking system</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Majestic hotel booking form Widget a Flat Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<!-- Meta tag Keywords -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" /><!-- Style-CSS -->
<link rel="stylesheet" href="css/font-awesome.min.css"><!--fontawesome-css--> 
<script src="js/jquery-2.1.4.min.js"></script>
<link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
</head>
<body style="background-color:  #ccc;">

 <table border="1" align="center" width="50%" cellpadding="10px">

<tr>
	<td width="890px" height="500px" valign="top">


	  			<?php
                    $st ="Select * from reservation;";
                    $result = ShowData($st);
                    while($row = mysqli_fetch_assoc($result)){
                        
             
                                        
                                        echo 'First name::'.$row['Firstname']."<br>";  
                                        
                                        echo 'last name::'.$row['lastname']."<br>"; 

                                        echo 'check-in-date::'.$row['checkindate']."<br>";  
                                        
                                        echo 'check-out-date::'.$row['checkoutdate']."<br>"; 

                                        echo 'Purpose::'.$row['Purpose']."<br>"; 

                                        echo 'Room-number::'.$row['Roomnumber']."<br>"; 

                                        echo 'Description::'.$row['Description']."<br>";   
                                        echo "<br>";

                                                   
}
                                     
                                   // echo'</div>

                                     //  <a href="notice-details.php?value='.$row['id'].'">LEARN Now</a>';
                            ?>

	</td>
</tr>


</table>



<div class="clear"></div>
</div>
<footer></footer>
</section>
<!--start-date-piker-->
		<link rel="stylesheet" href="css/jquery-ui.css" />
		<script src="js/jquery-ui.js"></script>
			<script>
				$(function() {
				$( "#datepicker,#datepicker1" ).datepicker();
				});
			</script>
<!-- /End-date-piker -->
</body>
</html>