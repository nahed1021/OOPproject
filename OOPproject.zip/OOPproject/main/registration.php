<?php 
    require 'database.php';

            if ($_SERVER['REQUEST_METHOD'] == 'POST')
            {
                $name=$_POST['name'];
                $username = $_POST['username'];
                $password = $_POST["password"];
                
                
                $st="Insert into user(name,username,password) values('$name','$username','$password');";
                
                Insert($st);
                echo "<script> location.href='login.php';</script>";
            }
                
?>



<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resort Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
    function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
<link rel="stylesheet" type="text/css" href="css/zoomslider.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script type="text/javascript" src="js/modernizr-2.6.2.min.js"></script>
<!--/web-fonts-->
<link href="//fonts.googleapis.com/css?family=Dosis:200,300,400,500,600" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
<!--//web-fonts-->
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
  echo "It works!";
}
?>
        <div id="demo-1" data-zs-src='["images/5.jpg", "images/2.jpg", "images/1.jpg","images/3.jpg"]' data-zs-overlay="dots">
    <div class="demo-inner-content">
    <!--/header-w3l-->
         <div class="header-w3-agileits" id="home">
           <div class="inner-header-agile"> 
                <nav class="navbar navbar-default">
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                    <h1><a  href="index.php"><span>R</span>oom <p class="s-log">Booking</p></a>
                     
                    </h1>
                  </div>
                  <!-- navbar-header -->
                  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    
         <ul class="nav navbar-nav">
                      <li><a href="index.php">Home</a></li>
                        <li><a href="roominfo.php" target="--blank">roominfo</a></li>
                        <li><a href="login.php" target="--blank">Reservation</a></li>
                        <li><a href="gallery.php" target="--blank">Gallery</a></li>
                        
                         <li><a href="login.php" target="--blank">Login</a></li>
                         

                        <li><a href="contact.php">Contact</a></li>

                      
                    </ul>


                  </div>
                  <div class="clearfix"> </div> 
                </nav>
                  <div class="w3ls_search">
                          <div class="cd-main-header">
                            <ul class="cd-header-buttons">
                              <li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
                            </ul> <!-- cd-header-buttons -->
                          </div>
                          <div id="cd-search" class="cd-search">
                            <form action="#" method="post">
                              <input name="Search" type="search" placeholder="Search...">
                            </form>
                          </div>
                        </div>
          
              </div> 

      
  

    <!--//header-->


    <!--registration-->

    <!--registration end-->

      <!--registration-->
   <script src="http://mymaplist.com/js/vendor/TweenLite.min.js"></script>

<div class="container">
    <div class="row vertical-offset-100">
      <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">Please register</h3>
        </div>
          <div class="panel-body">
            <form action="" method="post">
                    <fieldset>
                    <div class="form-group">
                  <input class="form-control" placeholder="name" name="name" type="text" required="">
              </div>
                <div class="form-group">
                  <input class="form-control" placeholder="username" name="username" type="text" required="">
              </div>
              <div class="form-group">
                <input class="form-control" placeholder="Password" name="password" type="password" value="" required="">
              </div>
              <!--<div class="checkbox">
                  <label>
                    <input name="remember" type="checkbox" value="Remember Me"> Remember Me
                  </label>
                </div>-->
              <input class="btn btn-lg btn-success btn-block" type="submit" name="submit" value="registration">
            </fieldset>
              </form>
          </div>
      </div>
    </div>
  </div>
</div>
      <!--registration end-->
      
    </div>
       </div>
    </div>

   


</body>
</html>